<?php 
class ICT { 
	private $studentId;
	private $pwd; 
	public function updatePwd($studentId, $pwd){ 
		echo("Function to update password '". $pwd . "' for user " . $studentId); 
		echo "<br>"; 
	} 
	public function courseCode($studentId) { 
		echo("Function to check course code of student ". $studentId); 
		echo "<br>"; 
	} 
} 
$obj = new ICT();
$obj -> updatePwd("ICT45", "ict123");
$obj -> courseCode("SWT22022");
?>