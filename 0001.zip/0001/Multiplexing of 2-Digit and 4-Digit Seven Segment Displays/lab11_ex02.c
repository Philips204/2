#define DIGIT1 PORTA.RA0
#define DIGIT2 PORTA.RA1
#define DIGIT3 PORTA.RA2
#define DIGIT4 PORTA.RA3

unsigned char Display(unsigned char nums)
{
      unsigned char pattern;
      unsigned int numbers[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
      pattern=numbers[nums];
      return(pattern);
}               //disply meth0d

void main()
{
unsigned char n1,n2,n3,n4;
unsigned char number = 712;

 TRISA=0;
 TRISD=0;//AS OUTPUTS             ,


 DIGIT1=0; //first enable pins off
 DIGIT2=0;
 DIGIT3=0;
 DIGIT4=0;


 while(1)
 {
      n1=number%10;
     PORTD= Display(number);
     DIGIT4=1;
     delay_ms(100);
     DIGIT4=0;
     
     n3=(number/10)%10;
     PORTD= Display(number);
     DIGIT3=1;
     delay_ms(100);
     DIGIT3=0;
     
     n2=(number/100)%10;
     PORTD= Display(number);
     DIGIT2=1;
     delay_ms(100);
     DIGIT2=0;
     
     n1=(number/1000)%10;
     PORTD= Display(number);
     DIGIT1=1;
     delay_ms(100);
     DIGIT1=0;
     

     
     





 }




}