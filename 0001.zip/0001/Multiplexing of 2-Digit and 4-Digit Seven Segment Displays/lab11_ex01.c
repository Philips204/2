
#define DIGIT1 PORTA.RA0
#define DIGIT2 PORTA.RA1

unsigned char Display(unsigned char nums)
{
      unsigned char pattern;
      unsigned int numbers[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
      pattern=numbers[nums];
      return(pattern);
}               //disply meth0d

void main()
{
unsigned char msd ,lsd,number=53;
 TRISA=0;
 TRISD=0;//AS OUTPUTS
 

 DIGIT1=0; //first enable pins off
 DIGIT2=0;
 
 while(1)
 {
     msd=number/10;
     PORTD= Display(msd);
     DIGIT2=1;
     delay_ms(50);
     
     DIGIT2=0;
     
      lsd=number%10;
      PORTD= Display(lsd);
      DIGIT1=1;
      delay_ms(50);
      DIGIT1=0;
      
      
      
 }
 
 
 
 
}