#define Max_Notes 25

void main() {
 unsigned char i;
 unsigned int Notes[Max_Notes] =
 {
  262, 262, 294, 262, 349, 330, 262, 262, 294, 262, 392, 349, 262, 262, 524, 440, 349, 330, 294, 466, 466, 440, 349, 392, 349
 };

  unsigned char Durations[Max_Notes] =
  {
   1, 1, 2, 2, 2, 3, 1, 1, 2, 2, 2, 3, 1, 1, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 3,
  };
  
  Sound_Init(&PORTC, 2); //Initialize the Sound library
  
  for(;;) //Endless loop
  {
   for(i = 0; i < Max_Notes; i++) //Do for all notes
   {
    Sound_Play(Notes[i], 100*Durations[1]); //Play the notes
    Delay_ms(100); //Note Gap
   }
   Delay_Ms(3000); // Repeat after 3s
  }
}
   
    