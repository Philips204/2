
int j,i;
unsigned numbers[]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};
void main()
{
     TRISB=TRISC=0;
     PORTB=PORTC=0;
     
     for(;;)
     {
         for(i=0;i<10;i++)
         {
            PORTC=numbers[i];
            for(j=0;j<10;j++)
            {
              PORTB=numbers[J];
              delay_ms(500);
            }
         }
     
     }
}