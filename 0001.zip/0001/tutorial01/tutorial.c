void main()
{        TRISB.F0=1;  //input
         TRISC=0x00;  //output
         PORTC=0x00;  //leds

        while(1)
        {
           PORTC=0xFF;
          delay_ms(50);
          PORTC=0x00;
          delay_ms(50);
        }
}