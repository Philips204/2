void main()
 {
      TRISB.F0 = 0;    //Configure 1st bit of PORTD as input
      TRISD.F0 = 1;   //Configure 1st bit of PORTB as output
      PORTB.F0 = 0;  //LED OFF
         while(1)
          {  // Infinite loop
                 if (PORTD.F0==1)  //If the switch is pressed
                     { PORTB.F0 = 1; } //LED ON
                 else  // If the switch is released
                     { PORTB.F0 = 0; } //LED OFF
             }
 
 
 

}