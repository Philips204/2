//LCD Module connection
sbit LCD_RS at RC0_bit;
sbit LCD_EN at RC1_bit;
sbit LCD_D4 at RC2_bit;
sbit LCD_D5 at RC3_bit;
sbit LCD_D6 at RC4_bit;
sbit LCD_D7 at RC5_bit;
// direction
sbit LCD_RS_Direction at TRISC0_bit;
sbit LCD_EN_Direction at TRISC1_bit;
sbit LCD_D4_Direction at TRISC2_bit;
sbit LCD_D5_Direction at TRISC3_bit;
sbit LCD_D6_Direction at TRISC4_bit;
sbit LCD_D7_Direction at TRISC5_bit;
//pressure measurement
unsigned int ADCResult=0;
float pressure;     //getting presser from sensor
unsigned char text[15]; //disply text/15 characters
void main()
{
   TRISA.RA0=1;//Ra0 pin as input
   ADC_Init();
   LCD_Init();
   Lcd_Cmd(_LCD_CLEAR);
   Lcd_Cmd(_LCD_CURSOR_OFF);
   Lcd_Out(1,1,"Pressure : ");
   delay_ms(500);
                                          Lcd_Cmd(_LCD_CLEAR);
   while(1)
   {
        ADCResult=ADC_Read(0);
        pressure = (ADCResult*5.0)/1023; //formular for convert digital
        pressure = (pressure + 0.475)/0.0475;   ////formular for convert digital
        
        FloatToStr(pressure, text);  //float value to charactes
        Lcd_Out_Cp(text); //cp mean cursor point
        Lcd_Out_Cp("kPa");
}
      ///Worning!! CODE is RIGHT BUT SOFTWARE ERROR
}