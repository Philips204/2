void main()
{   int x ;
    TRISC=0x00;

    while(1)
    {

      for(x=1;x<=3;x++)
      {
        PORTC=0xFF;
        delay_ms(200);
        PORTC=0x00;
        delay_ms(200);

      }
      PORTC=0x00;
      delay_ms(2000);

    }
}