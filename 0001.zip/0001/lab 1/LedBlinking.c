void main()
{


   TRISC=0x00;
   PORTC=0x00;


 while(1)
    {

      PORTC=0xFF;
      delay_ms(500);
       PORTC=0x00;
       delay_ms(500);

    }

}