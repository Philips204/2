
//initialize lcd
sbit LCD_RS at RC0_bit;
sbit LCD_EN at RC1_bit;
sbit LCD_D4 at RC2_bit;
sbit LCD_D5 at RC3_bit;
sbit LCD_D6 at RC4_bit;
sbit LCD_D7 at RC5_bit;

// lcd directions
sbit LCD_RS_Direction at TRISC0_bit;
sbit LCD_EN_Direction at TRISC1_bit;
sbit LCD_D4_Direction at TRISC2_bit;
sbit LCD_D5_Direction at TRISC3_bit;
sbit LCD_D6_Direction at TRISC4_bit;
sbit LCD_D7_Direction at TRISC5_bit;

int ldr;//light indensity digitsl value
char value[2];//value from LDR sensor


void main()
{

        
        ADC_Init();
        Lcd_Init();
        
        Lcd_Cmd(_LCD_CLEAR);
        Lcd_Cmd(_LCD_CURSOR_OFF);
        
        Lcd_Out(1,1,"Light Indensity");
        delay_ms(500);
        Lcd_Cmd(_LCD_CLEAR);
        
        while(1)
        {
             ldr = ADC_Read(0);
             ldr=100-ldr/10.24;//convert int to srting
             inttostr(ldr,value);
             Lcd_Out(2,2,value);
             delay_ms(1000);
             Lcd_Cmd(_LCD_CLEAR);
             

             
        }

}