

int light;
void read_ldr()
{
unsigned int adc_value=0;
adc_value=ADC_Read(0);
light =100-adc_value/10.24;
if(light>=80) // SWITCH of the light when light is 80 percent
{
PORTC=0;

}
else
{
PORTC=1;

}
}
void main()
{
TRISC=0X00;
PORTC=0X00;
Adc_Init();

while (1)
{
read_ldr();
}
}