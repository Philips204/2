//LCD Module Connections
sbit LCD_RS at RD6_bit;
sbit LCD_EN at RD7_bit;
sbit LCD_D4 at RB4_bit;
sbit LCD_D5 at RB5_bit;
sbit LCD_D6 at RB6_bit;
sbit LCD_D7 at RB7_bit;

//LCD pin Connection

sbit LCD_RS_Direction at TRISD6_bit;
sbit LCD_EN_Direction at TRISD7_bit;
sbit LCD_D4_Direction at TRISB4_bit;
sbit LCD_D5_Direction at TRISB5_bit;
sbit LCD_D6_Direction at TRISB6_bit;
sbit LCD_D7_Direction at TRISB7_bit;


void main()
{

   
   while(1)
   {
   Lcd_Init();//initialize lcd
   Lcd_Cmd(_LCD_CLEAR);//clear disply
   Lcd_Cmd(_LCD_CURSOR_OFF); //off the cursor
   Lcd_Out(1,1,"Hello User");
   Lcd_Out(2,1,"Hello User");
   delay_ms(500);
   
   }
   
   
   
   

}