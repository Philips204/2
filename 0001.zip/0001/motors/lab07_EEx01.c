
void main() 
{
   TRISD=0b00000000;//define the port D as OUTPUT
   PORTD=0b11111111;//define the port D as input of motor
   
   while()
   {
      k
   }
}