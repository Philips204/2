

void main() 
{
   TRISD=0b00000000;//define portD as Output
   PORTD=0b11111111;
   
   while(1)
   {
      PORTD=0b00000011;//first 1,2 of trassitor as =1 for become twoface to motor
      delay_ms(2000);
      PORTD=0b00000110;
      delay_ms(2000);
       PORTD=0b00001100;
      delay_ms(2000);
      PORTD=0b00001001;
      delay_ms(2000);
      
   }
}