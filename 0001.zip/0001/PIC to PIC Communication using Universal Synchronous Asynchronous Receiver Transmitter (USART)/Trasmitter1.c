void main() 
{
    TRISB=0xFF;//  configure portB as input
    PORTB=0;
    
    UART1_Init(9600); //initialize UART communication     9600 tare of bitpersecond
    delay_ms(100);
    
    while(1)
    {
       UART1_Write(PORTB);//write function.destination  is receiver portB
       delay_ms(500);
       
    }
    
}