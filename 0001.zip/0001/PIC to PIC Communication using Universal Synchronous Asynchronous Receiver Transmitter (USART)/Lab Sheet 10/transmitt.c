void main() {
     TRISB = 0xFF; //configure PortB as input
     PORTB = 0;

     UART1_Init(9600); //initialize UART communication
     delay_ms(100);

     while(1)
     {
      UART1_Write(PORTB);
      delay_ms(500);
     }
}