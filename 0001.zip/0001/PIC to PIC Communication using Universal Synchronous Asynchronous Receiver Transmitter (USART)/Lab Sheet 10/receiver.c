void main() {
     TRISB = 0; //configure PortB as an output
     PORTB = 0;
     
     UART1_Init(9600);
     delay_ms(100);
     
     while(1)
     {
      if(UART1_Data_Ready())//check the data availability
      {
       PORTB = UART1_Read();
      }
     }
}