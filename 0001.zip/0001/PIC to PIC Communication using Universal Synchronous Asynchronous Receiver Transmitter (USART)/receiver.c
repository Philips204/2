 void main()
 {
   TRISB=0;//configure portB as an output
   PORTB=0;
   
   UART1_Init(9600);
   delay_ms(100);
   
   while(1)
   {
      if(UART1_Data_Ready())//check data is available using this function
      {
            PORTB=UART1_Read();
      }
   }
   
}